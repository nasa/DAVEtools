// BlockMathMinus
//
//  Part of DAVE-ML utility suite, written by Bruce Jackson, NASA LaRC
//  <bruce.jackson@nasa.gov>
//  Visit <http://daveml.org> for more info.
//  Latest version can be downloaded from http://dscb.larc.nasa.gov/Products/SW/DAVEtools.html
//  Copyright (c) 2007 United States Government as represented by LAR-17460-1. No copyright is
//  claimed in the United States under Title 17, U.S. Code. All Other Rights Reserved.

package gov.nasa.daveml.dave;

/**
 *
 * <p> Minus value math function block </p>
 * <p> Was named BlockMathGain, but that isn't supported by mathml2?</p>
 * <p> 031211 Bruce Jackson <mailto:bruce.jackson@nasa.gov> </p>
 *
 **/

import org.jdom.Element;

import java.io.IOException;
import java.io.Writer;
import java.util.List;
import java.util.Iterator;

/**
 *
 * <p> The BlockMathMinus block represents a minus block </p>
 *
 **/

public class BlockMathMinus extends BlockMath
{
    /**
     *
     * <p> Constructor for Minus Block <p>
     *
     * @param applyElement Reference to <code>org.jdom.Element</code>
     * containing "apply" element
     * @param m		The parent <code>Model</code>
     *
     **/

    @SuppressWarnings("unchecked")
	public BlockMathMinus( Element applyElement, Model m )
    {
	// Initialize superblock elements
	super("pending", "inverter", m);

	// Parse parts of the Apply element
	List<Element> kids = applyElement.getChildren();
	Iterator<Element> ikid = kids.iterator();

	// first element should be our type; also use for name
	Element first = ikid.next();
	this.setName( first.getName() + "_" + m.getNumBlocks() );
	
	// take appropriate action based on type
	if(!first.getName().equals("minus"))  {
	    System.err.println("Error - BlockMathMinus constructor called with" +
			       " wrong type element.");
	} else
	    genInputsFromApply( ikid, 1 );
    }


    /**
     *
     * <p> Generates description of self </p>
     *
     * @throws <code>IOException</code>
     **/

    public void describeSelf(Writer writer) throws IOException
    {
	super.describeSelf(writer);
	writer.write(" and is a Minus block.");
    }

    /**
     *
     * <p> Implements update() method </p>
     * @throws DAVEException
     *
     **/

    public void update() throws DAVEException
    {

	if (isVerbose()) {
	    System.out.println();
	    System.out.println("Method update() called for breakpoint block '" + this.getName() + "'");
	}
	
	// Check to see if only one input
	if (this.inputs.size() < 1)
	    throw new DAVEException("Breakpoint block " + this.myName + " has no input.");

	if (this.inputs.size() > 1)
	    throw new DAVEException("Breakpoint block " + this.myName + " has more than one input.");

	// see if single input variable is ready
	Signal theInput = this.inputs.get(0);
	if (!theInput.sourceReady()) {
	    if (this.isVerbose())
		System.out.println(" Upstream signal '" + theInput.getName() + "' is not ready.");
	    return;
	}

	// get single input variable value
	double inputValue = theInput.sourceValue();
	if (this.isVerbose())
	    System.out.println(" Input value is " + inputValue);

	// Calculate output
	this.value = -inputValue;

	// record current cycle counter
	resultsCycleCount = ourModel.getCycleCounter();

    }
}
