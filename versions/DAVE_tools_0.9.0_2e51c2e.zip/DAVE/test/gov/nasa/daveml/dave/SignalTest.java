package gov.nasa.daveml.dave;

import org.jdom.Element;
import junit.framework.*;
import java.util.ArrayList;
import java.util.Iterator;



/**
 * Tests the Signal object
 *
 * 060913 Bruce Jackson, NASA Langley <mailto:bruce.jackson@nasa.gov>
 *
 **/

public class SignalTest extends TestCase {

    Signal _ds; // default signal constructor
    Signal _ss; // simple signal constructor
    Signal _fs; // full signal constructor
    Signal _cs; // signal from var def with calculation
    Block  _bc; // upstream constant block
    Block  _bd; // downstream output block
    Model  _m;  // parent model for simple system 

    protected void setUp() {
        _m  = new Model(3,3);
        _ds = new Signal();
        _ss = new Signal( "new signal", _m );
        _fs = new Signal( "full signal", "fulsig", "deg", 4, _m );
        _bc = new BlockMathConstant( "-3.45", _m );
        _bd = new BlockOutput( _ss, _m );

    }  // end of setup


    public void testDefaultCtor() {
        assertTrue( _ds.getName() == "" );
        try {
            assertTrue( _ds.sourceReady() ); // should fail; no block
            fail("Expected exception.");
        } catch ( DAVEException e ) { 
            assertTrue( true );         // should throw exception
        }
        assertTrue(  _ds.getVarID() == "" );
        assertTrue(  _ds.getUnits() == "" );
        assertTrue(  _ds.getSource() == null );
        assertTrue(  _ds.getSourcePort() == 0 );
        assertFalse( _ds.hasSource() );
        assertFalse( _ds.hasDest() );
        assertFalse( _ds.hasIC() );
        assertFalse( _ds.isOutput() );
        assertFalse( _ds.isAutomatic() );
    }

    public void testFullCtor() {
        assertTrue(  _fs.getName() == "full signal" );
        assertTrue(  _fs.getVarID() == "fulsig" );
        assertTrue(  _fs.getUnits() == "deg" );
        assertTrue(  _fs.getSource() == null );
        assertTrue(  _fs.getSourcePort() == 0 );
        assertFalse( _fs.hasSource() );
        assertFalse( _fs.hasDest() );
        assertFalse( _fs.hasIC() );
        assertFalse( _fs.isOutput() );
        assertFalse( _fs.isAutomatic() );
    }

    public void testSingleSignal() {
                
        // build a Signal from by tying in existing Blocks (defined in setUp())
        // this does not use XML snippet

        assertTrue( _bd != null );

        assertTrue( _ss.getName() == "new signal" );
        try {
            assertTrue( _ss.sourceReady() ); // should fail; no block
            fail("Expected to receive an exception.");
        } catch ( DAVEException e ) { 
            assertTrue( true );
        }

        try { _bc.update(); }
        catch (DAVEException e) {
            fail("Exception thrown while performing update of constant block in testSingleSignal: " + e.getMessage());
        }

        try { 
            _bc.addOutput( _ss );
            assertTrue( _ss.sourceReady() );
        } catch (DAVEException e) {
            fail("Exception thrown while adding output to constant block in testSingleSignal: " + e.getMessage());
        }

        try {
            assertEquals( -3.45, _ss.sourceValue(), 0.0000001 );
        } catch (DAVEException e) {
            fail("Exception thrown while getting value of signal source in testSingleSignal: " + e.getMessage());
        }

        try { _m.initialize(); }
        catch (DAVEException e ) {
            fail("Exception thrown while initializing model in testSingleSignal: " + e.getMessage());
        }

        assertTrue(  _ss.getVarID() == "new signal" );
        assertTrue(  _ss.getUnits() == "unkn" );
        assertTrue(  _ss.getSource() == _bc );
        assertTrue(  _ss.getSourcePort() == 1 );
        assertTrue(  _ss.hasSource() );
        assertTrue(  _ss.hasDest() );
        assertFalse( _ss.hasIC() );
        assertFalse( _ss.isOutput() );
        assertFalse( _ss.isAutomatic() );

        BlockArrayList dests = _ss.getDests();
        assertTrue( dests != null );
        assertTrue( dests.size() == 1 );
        Iterator<Block> dbi = dests.iterator();
        assertTrue( dbi.hasNext() );
        Block destBlock = (Block) dbi.next();
        assertTrue( destBlock == _bd );

        ArrayList<Integer> destPorts = _ss.getDestPortNumbers();
        assertTrue( destPorts != null );
        assertTrue( destPorts.size() == 1 );
        Iterator<Integer> dpi = destPorts.iterator();
        assertTrue( dpi.hasNext() );
        Integer destPort = (Integer) dpi.next();
        assertTrue( destPort == 1 );
    }

    public void testVerbose() {
        assertFalse( _ss.isVerbose() );
        _ss.makeVerbose();
        assertTrue( _ss.isVerbose() );
        _ss.silence();
        assertFalse( _ss.isVerbose() );
    }

    public void testDeepCopy() {
        Signal s2 = new Signal( _fs );
        assertTrue( s2.getName() == "full signal" );
        assertTrue( s2.getVarID() == "fulsig" );
        assertTrue( s2.getUnits() == "deg" );
        assertTrue( s2.getSource() == null );
        assertTrue( s2.getSourcePort() == 0 );
        assertFalse( s2.hasSource() );
        assertFalse( s2.hasDest() );
        assertFalse( s2.hasIC() );
        assertFalse( s2.isOutput() );
        assertFalse( s2.isAutomatic() );
        try {
            assertTrue( _ds.sourceReady() );
            fail("Expected exception.");
        } catch ( DAVEException e ) { 
            assertTrue( true );
        }
    }

    public void testSignalElementWithNumericConstant_ctor() {

        // test building an abs value network from the XML snippet
                
        // delete existing Signals and Blocks
        _ds = null;
        _ss = null;
        _fs = null;
        _bc = null;
        _bd = null;
                
        // create a simple calculated vardef to test the Signal methods
        //   <variableDef name="calcVar" varID="dv" units="deg">
        //     <description>
        //       My description
        //     </description>
        //     <calculation>
        //       <math>
        //         <apply><abs/><cn>-6.78</cn></apply>
        //       </math>
        //     </calculation>
        //   </variableDef>

        Element theDesc1 = new Element("description");
        theDesc1.addContent("My description");

        Element theValue = new Element("cn");
        theValue.addContent( "-6.78" );

        Element absElement = new Element("abs");

        Element applyElement = new Element("apply");
        applyElement.addContent( absElement );
        applyElement.addContent( theValue );

        Element mathElement = new Element("math");
        mathElement.addContent( applyElement );

        Element calcElement = new Element("calculation");
        calcElement.addContent( mathElement );

        Element calcVarDef; // varDef with calculation component

        calcVarDef = new Element("variableDef");
        calcVarDef.setAttribute( "name", "calcVar" );
        calcVarDef.setAttribute( "varID", "dv" );
        calcVarDef.setAttribute( "units", "deg" );
        calcVarDef.addContent( theDesc1 );
        calcVarDef.addContent( calcElement );
                
        // use new model empty of blocks and signals
        Model m = new Model(3,3);
                
        Signal theSignal = new Signal(calcVarDef, m); // this creates single upstream BlockMathAbs named "abs_1"
        assertTrue(  theSignal != null );
        assertTrue(  theSignal.hasSource() );
        assertFalse( theSignal.hasDest() );
        assertFalse(  theSignal.hasIC() );

        // verify information about newly-created block
        Block abs_1 = theSignal.getSource();
        assertTrue(                  abs_1 != null );
        assertEquals( "abs_1",       abs_1.getName() );
        assertEquals( 1,             abs_1.numInputs() );
        assertEquals( 1,             abs_1.numVarIDs() );
        assertTrue(                  abs_1.allInputsConnected() );
        assertEquals( "const_-6.78_",abs_1.getVarID(1) );
        assertEquals( "dv",          abs_1.getOutputVarID() );
        assertEquals( theSignal,     abs_1.getOutput() );
        assertTrue(                  abs_1.outputConnected() );

        // verify information about the Model
        assertTrue( m != null );
        assertEquals( 2, m.getNumBlocks() );
        assertEquals( 2, m.getNumSignals() );
        assertEquals( 0, m.getNumInputBlocks() );
        assertEquals( 0, m.getNumOutputBlocks() );

        try { m.initialize(); }
        catch (DAVEException e ) {
            fail("Exception thrown while initializing model in testSingleSignal_ctor: " + e.getMessage());
        }
                
        try {
            //      assertTrue( theSignal.sourceReady() );
            assertEquals( 6.78, theSignal.sourceValue(), 0.0000001 );
        } catch (DAVEException e) {
            fail("Exception thrown while getting value of signal source in testSingleElement_ctor: " 
                 + e.getMessage());
        }

    }

    public void testSignalElementWithBlockConstant_ctor() {

        // test building an abs value network from the XML snippet
                
        // delete existing Signals and Blocks
        _ds = null;
        _ss = null;
        _fs = null;
        _bc = null;
        _bd = null;
                
        // create a simple calculated vardef to test the Signal methods
        // define upstream constant
        //   <variableDef name="beta" varID="beta" units="deg" initialValue="-6.78"/>
        //   <variableDef name="calcVar" varID="dv" units="deg">
        //     <description>
        //       My description
        //     </description>
        //     <calculation>
        //       <math>
        //         <apply><abs/><ci>beta</ci></apply>
        //       </math>
        //     </calculation>
        //   </variableDef>

        Element theDesc1 = new Element("description");
        theDesc1.addContent("My description");

        Element theValue = new Element("ci");
        theValue.addContent( "beta" );

        Element absElement = new Element("abs");

        Element applyElement = new Element("apply");
        applyElement.addContent( absElement );
        applyElement.addContent( theValue );

        Element mathElement = new Element("math");
        mathElement.addContent( applyElement );

        Element calcElement = new Element("calculation");
        calcElement.addContent( mathElement );

        Element calcVarDef; // varDef with calculation component
        Element constVarDef; // varDef for upstream constant

        calcVarDef = new Element("variableDef");
        calcVarDef.setAttribute( "name", "calcVar" );
        calcVarDef.setAttribute( "varID", "dv" );
        calcVarDef.setAttribute( "units", "deg" );
        calcVarDef.addContent( theDesc1 );
        calcVarDef.addContent( calcElement );
                
        // use new model empty of blocks and signals
        Model m = new Model(3,3);
                
        // define the constant value
        constVarDef = new Element( "variableDef" );
        constVarDef.setAttribute(  "name", "beta" );
        constVarDef.setAttribute(  "varID", "beta" );
        constVarDef.setAttribute(  "units", "deg" );
        constVarDef.setAttribute( "initialValue", "-6.78" );
                
        // this wire will lead from a const block that is created by model.hookupIO()
        Signal beta = new Signal( constVarDef, m);
        assertTrue(  beta != null );
        assertFalse( beta.hasSource() );
        assertFalse( beta.hasDest() );
        assertTrue(  beta.hasIC() );
                
        // this creates single upstream BlockMathAbs named "abs_1"
        Signal dv = new Signal( calcVarDef, m ); 
        assertTrue(  dv != null );
        assertTrue(  dv.hasSource() );
        assertFalse( dv.hasDest() );
        assertFalse( dv.hasIC() );

        // verify information about newly-created block
        Block abs_1 = dv.getSource();
        assertTrue(            abs_1 != null );
        assertEquals( "abs_1", abs_1.getName() );
        assertEquals( 1,       abs_1.numInputs() );
        assertEquals( 1,       abs_1.numVarIDs() );
        assertFalse(           abs_1.allInputsConnected() );
        assertEquals( "beta",  abs_1.getVarID(1) );
        assertEquals( "dv",    abs_1.getOutputVarID() );
        assertEquals( dv,      abs_1.getOutput() );
        assertTrue(            abs_1.outputConnected() );
                
        // verify information about the Model
        assertTrue( m != null );
        assertEquals( 1, m.getNumBlocks() );
        assertEquals( 2, m.getNumSignals() );
        assertEquals( 0, m.getNumInputBlocks() );
        assertEquals( 0, m.getNumOutputBlocks() );

        // at this point, Model "m" has one block (BlockMathAbs "abs_1") and two Signals (dv and beta)
        // Signal "dv" is connected to output of BlockMathAbs "abs_1" but has no output
        // Signal "beta" is not connected to anything (input or output block) but has an IC value
        // Block "abs_1" is connected to output Signal "dv" but is not yet connected to input Signal "beta"
        //     but "abs_1" knows the varID of its single input is "beta"
        //
        //                    +------------------+  
        //       beta         |                  |   dv
        //     --------       | beta  abs_1   dv +--------
        //      -6.78         |                  |
        //                    +------------------+
        //
                                
        m.wireBlocks();  // this should connect beta as input to BMA
        //
        //                    +------------------+  
        //       beta         |                  |   dv
        //     -------------->| beta  abs_1   dv +--------
        //      -6.78         |                  |
        //                    +------------------+
        //
                
        // check input signal attributes for changes
        assertTrue(  beta != null );
        assertFalse( beta.hasSource() );
        assertTrue(  beta.hasDest() );    // this should have changed
        assertTrue(  beta.hasIC() );
                
        // check output signal attributes for changes
        assertTrue(  dv != null );
        assertTrue(  dv.hasSource() );
        assertFalse( dv.hasDest() );
        assertFalse( dv.hasIC() );
                
        // check BMA for changes
        assertTrue(            abs_1 != null );
        assertEquals( "abs_1", abs_1.getName() );
        assertEquals( 1,       abs_1.numInputs() );
        assertEquals( 1,       abs_1.numVarIDs() );
        assertTrue(            abs_1.allInputsConnected() );  // this should have changed
        assertEquals( "beta",  abs_1.getVarID(1) );
        assertEquals( "dv",    abs_1.getOutputVarID() );
        assertEquals( dv,      abs_1.getOutput() );
        assertTrue(            abs_1.outputConnected() );

        // check Model for changes
        assertTrue( m != null );
        assertEquals( 1, m.getNumBlocks() );
        assertEquals( 2, m.getNumSignals() );
        assertEquals( 0, m.getNumInputBlocks() );
        assertEquals( 0, m.getNumOutputBlocks() );

        // now create new BlockMathConstant "const_-6.78_" and hook it to "beta" signal
        // this step also creates an output port for dv to hook to
        m.hookupIO();
                
        //
        //   +--------------+       +------------------+      +---------+
        //   |              | beta  |                  |  dv  |         |
        //   |  const  beta +------>| beta  abs_1   dv +----->|  output |
        //   |  -6.78       | -6.78 |                  |      |         |
        //   +--------------+       +------------------+      +---------+
        //
                
        // check input signal attributes for changes
        assertTrue(  beta != null );
        assertTrue(  beta.hasSource() );   // this should have changed
        assertTrue(  beta.hasDest() );
        assertTrue(  beta.hasIC() );
                
        // check output signal attributes for changes
        assertTrue(  dv != null );
        assertTrue(  dv.hasSource() );
        assertTrue(  dv.hasDest() );      // this should have changed
        assertFalse( dv.hasIC() );
                
        // check BMA for changes
        assertTrue(            abs_1 != null );
        assertEquals( "abs_1", abs_1.getName() );
        assertEquals( 1,       abs_1.numInputs() );
        assertEquals( 1,       abs_1.numVarIDs() );
        assertTrue(            abs_1.allInputsConnected() );
        assertEquals( "beta",  abs_1.getVarID(1) );
        assertEquals( "dv",    abs_1.getOutputVarID() );
        assertEquals( dv,      abs_1.getOutput() );
        assertTrue(            abs_1.outputConnected() );

        // check Model for changes
        assertTrue( m != null );
        assertEquals( 3, m.getNumBlocks() );       // this should have changed
        assertEquals( 2, m.getNumSignals() );
        assertEquals( 0, m.getNumInputBlocks() );
        assertEquals( 1, m.getNumOutputBlocks() ); // this should have changed
                
        try { m.initialize(); }
        catch (DAVEException e ) {
            fail("Exception thrown while initializing model in testSingleSignal_ctor: " + e.getMessage());
        }
                
        try {
            assertTrue( dv.sourceReady() );
            assertEquals( 6.78, dv.sourceValue(), 0.0000001 );
        } catch (DAVEException e) {
            fail("Exception thrown while getting value of signal source in testSingleElement_ctor: " 
                 + e.getMessage());
        }

    }

    public static Test suite() {
        return new TestSuite( SignalTest.class );
    }

    public static void main (String[] args) {
        junit.textui.TestRunner.run(suite());
    }

}
