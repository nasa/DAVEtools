package gov.nasa.daveml.dave;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Iterator;

import org.jdom.Element;

import junit.framework.TestCase;

public class BlockMathMinusTest extends TestCase {

    protected Model _model;
    protected Signal _minusBeta;
    protected Signal _betaSignal;
    protected String _betaSignalID;
    protected BlockMathMinus _block;
    protected BlockMathConstant _constantBlock;
    private   StringWriter _writer;
    
    protected void setUp() {

        // don't need input signal - can create const block and signal in one step later
        _model   = new Model(3,3);
        _minusBeta = new Signal( "minusBeta", "minusBeta", "deg", 4, _model );
        _writer  = new StringWriter();
        
        // build an minus value apply element
        //   <apply>
        //     <minus/>
        //     <ci>beta</ci>
        //   </apply>

        Element theValue = new Element("ci");   // add numeric constant
        theValue.addContent( "beta" );

        Element minusEl = new Element("minus");
        minusEl.addContent( theValue );

        Element applyElement = new Element("apply");
        applyElement.addContent( minusEl );
        
        // create abs block
        _block     = new BlockMathMinus( applyElement, _model );

        // add constant-block-fed input signal
        _block.addConstInput("-3.45", 1);
        
        // find and record location of newly-created constant block
        SignalArrayList sigList = _model.getSignals();
        _betaSignalID = _block.getVarID(1);
        _betaSignal = sigList.findByID(_betaSignalID);
        _constantBlock = (BlockMathConstant) _betaSignal.getSource();

        // add output signal
        try {
            _block.addOutput(_minusBeta);
        } catch (DAVEException e1) {
            fail("problem adding output signal to block in TestBlockMathMinus::setUp");
            e1.printStackTrace();
        }
        
        // probably redundant
        _model.wireBlocks();
        
        try {
            _model.initialize();
        } catch (DAVEException e) {
            fail("problem initializing model with BlockMathMinus");
            e.printStackTrace();
        }
    }
    
    public void testUpdate() {
        _constantBlock.setValue( 4.56 );
        try {
            _model.getInputVector();
        } catch (DAVEException e1) {
            fail("error when trying to obtain VectorInfoArrayList in TestBlockMathMinus::testUpdate()");
            e1.printStackTrace();
        }
        try {
            _model.cycle();
        } catch (DAVEException e) {
            fail("error when trying to cycle model in TestBlockMathMinus::testUpdate()");
            e.printStackTrace();
        }
        assertEquals( -4.56, _block.getValue(), 0.000001 );
    }

    public void testDescribeSelf() {
        try {
            _block.describeSelf(_writer);
        } catch (IOException e) {
            assertTrue(false);
            e.printStackTrace();
        }
        assertEquals( "Block \"minus_1\" has one input (const_-3.45_)," +
        		" one output (minusBeta), value [3.45] and is a Minus block.", 
                _writer.toString() );
    }

    public void testGetValue() {
        assertEquals( 3.45, _block.getValue(), 0.000001 );
    }

    public void testIsReady() {
        assertTrue(_block.isReady() );
    }

    public void testAllInputsReady() {
        assertTrue(_block.allInputsReady() );
    }

    public void testMakeVerbose() {
        assertFalse( _block.isVerbose() );
        _block.makeVerbose();
        assertTrue( _block.isVerbose() );
        _block.silence();
        assertFalse( _block.isVerbose() );
    }

    public void testGetModel() {
        assertEquals( _model.getName(), _block.getModel().getName() );
    }

    public void testGetSetName() {
        assertEquals( "minus_1", _block.getName() );
        _block.setName("fart");
        assertEquals( "fart", _block.getName() );
    }

    public void testGetType() {
        assertEquals( "inverter", _block.getType() );
    }

    public void testGetVarID() {
        assertEquals("const_-3.45_", _block.getVarID(1));
    }

    public void testGetVarIDIterator() {
        Iterator<String> it = _block.getVarIDIterator();
        assertTrue(it.hasNext());
        String s = it.next();
        assertEquals( _betaSignalID, s);
        assertFalse(it.hasNext());
    }

    public void testGetOutput() {
        Signal s = _block.getOutput();
        assertEquals( _minusBeta, s );
    }

    public void getGetInputIterator() {
        Iterator<Signal> it = _block.getInputIterator();
        assertTrue(it.hasNext());
        Signal s = it.next();
        assertEquals( _betaSignal, s );
        assertFalse(it.hasNext());
    }

    public void testGetOutputVarID() {
        assertEquals( "minusBeta", _block.getOutputVarID() );
    }

    public void testNumInputs() {
        assertEquals(1, _block.numInputs() );
    }

    public void testNumVarIDs() {
        assertEquals(1, _block.numVarIDs() );
    }

}
